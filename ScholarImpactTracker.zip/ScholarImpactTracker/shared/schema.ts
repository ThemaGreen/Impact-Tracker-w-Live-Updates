import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp, boolean } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const aiModels = pgTable("ai_models", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  vendor: text("vendor").notNull(),
  parameters: text("parameters"),
  releaseDate: text("release_date"),
  modelType: text("model_type").notNull(),
  avgKwhPerToken: real("avg_kwh_per_token"),
  avgCo2PerQuery: real("avg_co2_per_query"),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const researchPapers = pgTable("research_papers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  authors: text("authors").notNull(),
  abstract: text("abstract"),
  venue: text("venue"),
  publicationDate: text("publication_date"),
  citationCount: integer("citation_count").default(0),
  scholarUrl: text("scholar_url"),
  pdfUrl: text("pdf_url"),
  doi: text("doi"),
  isVerified: boolean("is_verified").default(false),
  addedAt: timestamp("added_at").defaultNow(),
});

export const impactMetrics = pgTable("impact_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  paperId: varchar("paper_id").references(() => researchPapers.id),
  modelId: varchar("model_id").references(() => aiModels.id),
  metricType: text("metric_type").notNull(),
  value: real("value").notNull(),
  unit: text("unit").notNull(),
  methodology: text("methodology"),
  confidenceLevel: text("confidence_level"),
  extractedAt: timestamp("extracted_at").defaultNow(),
});

export const scrapingJobs = pgTable("scraping_jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  query: text("query").notNull(),
  status: text("status").notNull().default("pending"),
  resultsCount: integer("results_count").default(0),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  errorMessage: text("error_message"),
});

export const aiModelsRelations = relations(aiModels, ({ many }) => ({
  metrics: many(impactMetrics),
}));

export const researchPapersRelations = relations(researchPapers, ({ many }) => ({
  metrics: many(impactMetrics),
}));

export const impactMetricsRelations = relations(impactMetrics, ({ one }) => ({
  paper: one(researchPapers, {
    fields: [impactMetrics.paperId],
    references: [researchPapers.id],
  }),
  model: one(aiModels, {
    fields: [impactMetrics.modelId],
    references: [aiModels.id],
  }),
}));

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertAiModelSchema = createInsertSchema(aiModels).omit({
  id: true,
  lastUpdated: true,
});

export const insertResearchPaperSchema = createInsertSchema(researchPapers).omit({
  id: true,
  addedAt: true,
});

export const insertImpactMetricSchema = createInsertSchema(impactMetrics).omit({
  id: true,
  extractedAt: true,
});

export const insertScrapingJobSchema = createInsertSchema(scrapingJobs).omit({
  id: true,
  startedAt: true,
  completedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertAiModel = z.infer<typeof insertAiModelSchema>;
export type AiModel = typeof aiModels.$inferSelect;

export type InsertResearchPaper = z.infer<typeof insertResearchPaperSchema>;
export type ResearchPaper = typeof researchPapers.$inferSelect;

export type InsertImpactMetric = z.infer<typeof insertImpactMetricSchema>;
export type ImpactMetric = typeof impactMetrics.$inferSelect;

export type InsertScrapingJob = z.infer<typeof insertScrapingJobSchema>;
export type ScrapingJob = typeof scrapingJobs.$inferSelect;
