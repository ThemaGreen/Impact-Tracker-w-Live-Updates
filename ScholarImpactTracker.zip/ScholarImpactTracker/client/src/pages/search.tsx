import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Search, Loader2, ExternalLink, Plus, Check, AlertCircle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface ScholarResult {
  title: string;
  authors: string;
  abstract?: string;
  venue?: string;
  year?: string;
  citationCount?: number;
  scholarUrl?: string;
  pdfUrl?: string;
}

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [submittedQuery, setSubmittedQuery] = useState("");
  const [importedIds, setImportedIds] = useState<Set<number>>(new Set());
  const { toast } = useToast();

  const { data: results, isLoading, isFetching, refetch } = useQuery<ScholarResult[]>({
    queryKey: [`/api/scholar/search?query=${encodeURIComponent(submittedQuery)}`],
    enabled: !!submittedQuery,
  });

  const importMutation = useMutation({
    mutationFn: async (paper: ScholarResult) => {
      return apiRequest("POST", "/api/papers", {
        title: paper.title,
        authors: paper.authors,
        abstract: paper.abstract || null,
        venue: paper.venue || null,
        publicationDate: paper.year ? `${paper.year}-01-01` : null,
        citationCount: paper.citationCount || 0,
        scholarUrl: paper.scholarUrl || null,
        pdfUrl: paper.pdfUrl || null,
      });
    },
    onSuccess: (_, paper) => {
      queryClient.invalidateQueries({ queryKey: ["/api/papers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Paper imported",
        description: `"${paper.title}" has been added to your database.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Import failed",
        description: "Failed to import paper. It may already exist in the database.",
        variant: "destructive",
      });
    },
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setSubmittedQuery(searchQuery.trim());
      setImportedIds(new Set());
    }
  };

  const handleImport = (paper: ScholarResult, index: number) => {
    importMutation.mutate(paper);
    setImportedIds((prev) => new Set([...prev, index]));
  };

  const suggestedQueries = [
    "AI carbon footprint",
    "LLM energy consumption",
    "GPT environmental impact",
    "machine learning sustainability",
    "neural network power consumption",
    "AI CO2 emissions training",
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight" data-testid="text-search-title">
          Search Google Scholar
        </h1>
        <p className="text-muted-foreground mt-1">
          Find and import research papers on AI environmental impact
        </p>
      </div>

      <Card>
        <CardContent className="p-6">
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="flex gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search for papers (e.g., 'AI carbon footprint', 'LLM energy consumption')"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 text-base"
                  data-testid="input-scholar-search"
                />
              </div>
              <Button type="submit" disabled={isFetching || !searchQuery.trim()} data-testid="button-search-scholar">
                {isFetching ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Searching...
                  </>
                ) : (
                  <>
                    <Search className="h-4 w-4 mr-2" />
                    Search
                  </>
                )}
              </Button>
            </div>

            {!submittedQuery && (
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Suggested searches:</p>
                <div className="flex flex-wrap gap-2">
                  {suggestedQueries.map((query) => (
                    <Button
                      key={query}
                      variant="outline"
                      size="sm"
                      type="button"
                      onClick={() => {
                        setSearchQuery(query);
                        setSubmittedQuery(query);
                      }}
                      data-testid={`button-suggest-${query.replace(/\s+/g, '-')}`}
                    >
                      {query}
                    </Button>
                  ))}
                </div>
              </div>
            )}
          </form>
        </CardContent>
      </Card>

      {isLoading && (
        <div className="space-y-4">
          {[1, 2, 3, 4, 5].map((i) => (
            <Card key={i}>
              <CardContent className="p-6 space-y-4">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <div className="flex gap-2">
                  <Skeleton className="h-8 w-24" />
                  <Skeleton className="h-8 w-20" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {!isLoading && submittedQuery && results && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground" data-testid="text-results-count">
              Found {results.length} result{results.length !== 1 ? 's' : ''} for "{submittedQuery}"
            </p>
            <Button variant="outline" size="sm" onClick={() => refetch()} disabled={isFetching}>
              Refresh results
            </Button>
          </div>

          {results.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <AlertCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="font-semibold text-lg">No results found</h3>
                <p className="text-muted-foreground mt-1">
                  Try adjusting your search query or using different keywords
                </p>
              </CardContent>
            </Card>
          ) : (
            results.map((paper, index) => (
              <Card key={index} data-testid={`card-result-${index}`}>
                <CardContent className="p-6 space-y-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-1">
                      <h3 className="font-semibold text-base leading-snug" data-testid={`text-result-title-${index}`}>
                        {paper.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">{paper.authors}</p>
                    </div>
                    <Button
                      size="sm"
                      variant={importedIds.has(index) ? "secondary" : "default"}
                      disabled={importedIds.has(index) || importMutation.isPending}
                      onClick={() => handleImport(paper, index)}
                      data-testid={`button-import-${index}`}
                    >
                      {importedIds.has(index) ? (
                        <>
                          <Check className="h-4 w-4 mr-1" />
                          Imported
                        </>
                      ) : (
                        <>
                          <Plus className="h-4 w-4 mr-1" />
                          Import
                        </>
                      )}
                    </Button>
                  </div>

                  {paper.abstract && (
                    <p className="text-sm text-muted-foreground line-clamp-3">
                      {paper.abstract}
                    </p>
                  )}

                  <div className="flex flex-wrap items-center gap-3 text-sm">
                    {paper.venue && (
                      <Badge variant="outline">{paper.venue}</Badge>
                    )}
                    {paper.year && (
                      <Badge variant="secondary">{paper.year}</Badge>
                    )}
                    {paper.citationCount !== undefined && (
                      <span className="text-muted-foreground font-mono">
                        {paper.citationCount} citations
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    {paper.scholarUrl && (
                      <Button variant="ghost" size="sm" asChild>
                        <a href={paper.scholarUrl} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4 mr-1" />
                          Scholar
                        </a>
                      </Button>
                    )}
                    {paper.pdfUrl && (
                      <Button variant="ghost" size="sm" asChild>
                        <a href={paper.pdfUrl} target="_blank" rel="noopener noreferrer">
                          PDF
                        </a>
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}

      {!submittedQuery && !isLoading && (
        <Card className="border-dashed">
          <CardContent className="p-12 text-center">
            <Search className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h3 className="font-semibold text-lg">Search for research papers</h3>
            <p className="text-muted-foreground mt-1 max-w-md mx-auto">
              Enter keywords related to AI environmental impact, energy consumption, or carbon emissions to find relevant academic papers.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
