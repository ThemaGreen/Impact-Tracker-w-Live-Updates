import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { FileText, Plus, RefreshCw } from "lucide-react";
import { SearchFilters, FilterState } from "@/components/search-filters";
import { PaperCard } from "@/components/paper-card";
import { EmptyState } from "@/components/empty-state";
import { PaperCardSkeleton } from "@/components/loading-skeleton";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import type { ResearchPaper } from "@shared/schema";

export default function PapersPage() {
  const [filters, setFilters] = useState<FilterState>({
    search: "",
    modelType: "",
    dateRange: "",
    metricType: "",
    citationThreshold: "",
  });

  const buildQueryString = () => {
    const params = new URLSearchParams();
    if (filters.search) params.set("search", filters.search);
    if (filters.dateRange) params.set("year", filters.dateRange);
    if (filters.citationThreshold) params.set("minCitations", filters.citationThreshold);
    const queryString = params.toString();
    return queryString ? `/api/papers?${queryString}` : "/api/papers";
  };

  const { data: papers, isLoading, refetch, isFetching } = useQuery<ResearchPaper[]>({
    queryKey: [buildQueryString()],
  });

  const filteredPapers = papers;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="text-papers-title">
            Research Papers
          </h1>
          <p className="text-muted-foreground mt-1">
            Browse and search AI environmental impact research
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => refetch()}
            disabled={isFetching}
            data-testid="button-refresh-papers"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isFetching ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Link href="/search">
            <Button size="sm" data-testid="button-add-paper">
              <Plus className="h-4 w-4 mr-2" />
              Add Paper
            </Button>
          </Link>
        </div>
      </div>

      <SearchFilters
        filters={filters}
        onFiltersChange={setFilters}
        placeholder="Search by title, authors, or abstract..."
      />

      {isLoading ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <PaperCardSkeleton />
          <PaperCardSkeleton />
          <PaperCardSkeleton />
          <PaperCardSkeleton />
          <PaperCardSkeleton />
          <PaperCardSkeleton />
        </div>
      ) : filteredPapers && filteredPapers.length > 0 ? (
        <>
          <p className="text-sm text-muted-foreground" data-testid="text-papers-count">
            Showing {filteredPapers.length} paper{filteredPapers.length !== 1 ? 's' : ''}
          </p>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredPapers.map((paper) => (
              <PaperCard key={paper.id} paper={paper} />
            ))}
          </div>
        </>
      ) : (
        <EmptyState
          icon={FileText}
          title="No papers found"
          description={
            filters.search || Object.values(filters).some(v => v)
              ? "Try adjusting your search or filters to find papers"
              : "Start by searching Google Scholar to import research papers"
          }
          action={{
            label: "Search Google Scholar",
            onClick: () => window.location.href = "/search",
          }}
          testId="empty-papers"
        />
      )}
    </div>
  );
}
