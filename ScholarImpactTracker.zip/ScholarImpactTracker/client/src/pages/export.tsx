import { useQuery } from "@tanstack/react-query";
import { Download, FileJson, FileSpreadsheet, FileText, Check } from "lucide-react";
import { ExportPanel } from "@/components/export-panel";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import type { ResearchPaper, AiModel, ImpactMetric } from "@shared/schema";

interface ExportStats {
  papersCount: number;
  modelsCount: number;
  metricsCount: number;
}

export default function ExportPage() {
  const { toast } = useToast();

  const { data: stats, isLoading: statsLoading } = useQuery<ExportStats>({
    queryKey: ["/api/export/stats"],
  });

  const { data: papers } = useQuery<ResearchPaper[]>({
    queryKey: ["/api/papers"],
  });

  const { data: models } = useQuery<AiModel[]>({
    queryKey: ["/api/models"],
  });

  const { data: metrics } = useQuery<ImpactMetric[]>({
    queryKey: ["/api/metrics"],
  });

  const downloadFile = (content: string, filename: string, mimeType: string) => {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleExport = (format: "csv" | "json" | "bibtex") => {
    const timestamp = new Date().toISOString().split('T')[0];

    if (format === "json") {
      const data = {
        exportDate: new Date().toISOString(),
        papers: papers || [],
        models: models || [],
        metrics: metrics || [],
      };
      downloadFile(JSON.stringify(data, null, 2), `ai-impact-data-${timestamp}.json`, 'application/json');
      toast({
        title: "Export complete",
        description: "JSON file has been downloaded.",
      });
    }

    if (format === "csv") {
      if (!papers || papers.length === 0) {
        toast({
          title: "No data to export",
          description: "Add some papers before exporting.",
          variant: "destructive",
        });
        return;
      }

      const headers = ["Title", "Authors", "Venue", "Publication Date", "Citations", "DOI", "Scholar URL"];
      const rows = papers.map(p => [
        `"${p.title.replace(/"/g, '""')}"`,
        `"${p.authors.replace(/"/g, '""')}"`,
        `"${(p.venue || '').replace(/"/g, '""')}"`,
        p.publicationDate || '',
        p.citationCount || 0,
        p.doi || '',
        p.scholarUrl || '',
      ]);

      const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
      downloadFile(csv, `ai-impact-papers-${timestamp}.csv`, 'text/csv');
      toast({
        title: "Export complete",
        description: "CSV file has been downloaded.",
      });
    }

    if (format === "bibtex") {
      if (!papers || papers.length === 0) {
        toast({
          title: "No data to export",
          description: "Add some papers before exporting.",
          variant: "destructive",
        });
        return;
      }

      const bibtex = papers.map((p, i) => {
        const key = p.title.split(' ').slice(0, 3).join('').toLowerCase().replace(/[^a-z]/g, '') + (p.publicationDate ? new Date(p.publicationDate).getFullYear() : '');
        const year = p.publicationDate ? new Date(p.publicationDate).getFullYear() : 'n.d.';
        return `@article{${key},
  title = {${p.title}},
  author = {${p.authors}},
  year = {${year}},
  journal = {${p.venue || 'Unknown'}},
  doi = {${p.doi || ''}},
  url = {${p.scholarUrl || ''}}
}`;
      }).join('\n\n');

      downloadFile(bibtex, `ai-impact-citations-${timestamp}.bib`, 'application/x-bibtex');
      toast({
        title: "Export complete",
        description: "BibTeX file has been downloaded.",
      });
    }
  };

  if (statsLoading) {
    return (
      <div className="space-y-6">
        <div>
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-96" />
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          <Skeleton className="h-[400px]" />
          <Skeleton className="h-[400px]" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight" data-testid="text-export-title">
          Export Data
        </h1>
        <p className="text-muted-foreground mt-1">
          Download research data in your preferred format for analysis or citations
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <ExportPanel
          papersCount={stats?.papersCount || papers?.length || 0}
          modelsCount={stats?.modelsCount || models?.length || 0}
          metricsCount={stats?.metricsCount || metrics?.length || 0}
          onExport={handleExport}
        />

        <Card>
          <CardHeader>
            <CardTitle>Export Options</CardTitle>
            <CardDescription>
              Choose what data to include in your export
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-start gap-4 p-4 rounded-md border">
                <FileSpreadsheet className="h-8 w-8 text-green-600 dark:text-green-400 shrink-0" />
                <div className="flex-1">
                  <h4 className="font-medium">Papers Dataset</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    Export all research papers with metadata including titles, authors, venues, citations, and publication dates.
                  </p>
                  <Button
                    variant="secondary"
                    size="sm"
                    className="mt-3"
                    onClick={() => handleExport("csv")}
                    data-testid="button-export-papers-csv"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download CSV
                  </Button>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 rounded-md border">
                <FileJson className="h-8 w-8 text-blue-600 dark:text-blue-400 shrink-0" />
                <div className="flex-1">
                  <h4 className="font-medium">Full Database</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    Export complete database including papers, AI models, and extracted impact metrics in JSON format.
                  </p>
                  <Button
                    variant="secondary"
                    size="sm"
                    className="mt-3"
                    onClick={() => handleExport("json")}
                    data-testid="button-export-full-json"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download JSON
                  </Button>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 rounded-md border">
                <FileText className="h-8 w-8 text-purple-600 dark:text-purple-400 shrink-0" />
                <div className="flex-1">
                  <h4 className="font-medium">Citations</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    Export paper citations in BibTeX format for use in LaTeX documents and academic papers.
                  </p>
                  <Button
                    variant="secondary"
                    size="sm"
                    className="mt-3"
                    onClick={() => handleExport("bibtex")}
                    data-testid="button-export-bibtex"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download BibTeX
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>API Access</CardTitle>
          <CardDescription>
            Access your data programmatically through our REST API
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-muted rounded-md">
              <p className="text-sm font-mono mb-2">GET /api/papers</p>
              <p className="text-xs text-muted-foreground">Retrieve all research papers</p>
            </div>
            <div className="p-4 bg-muted rounded-md">
              <p className="text-sm font-mono mb-2">GET /api/models</p>
              <p className="text-xs text-muted-foreground">Retrieve all AI models and their impact metrics</p>
            </div>
            <div className="p-4 bg-muted rounded-md">
              <p className="text-sm font-mono mb-2">GET /api/metrics</p>
              <p className="text-xs text-muted-foreground">Retrieve all extracted impact metrics</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
