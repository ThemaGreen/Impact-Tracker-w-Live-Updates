import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { BarChart3, Plus, RefreshCw } from "lucide-react";
import { ModelTable } from "@/components/model-table";
import { SearchFilters, FilterState } from "@/components/search-filters";
import { EmptyState } from "@/components/empty-state";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { AiModel } from "@shared/schema";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

const addModelSchema = z.object({
  name: z.string().min(1, "Model name is required"),
  vendor: z.string().min(1, "Vendor is required"),
  parameters: z.string().optional(),
  modelType: z.string().min(1, "Model type is required"),
  avgKwhPerToken: z.string().optional(),
  avgCo2PerQuery: z.string().optional(),
});

type AddModelForm = z.infer<typeof addModelSchema>;

export default function ModelsPage() {
  const [filters, setFilters] = useState<FilterState>({
    search: "",
    modelType: "",
    dateRange: "",
    metricType: "",
    citationThreshold: "",
  });
  const [dialogOpen, setDialogOpen] = useState(false);
  const { toast } = useToast();

  const { data: models, isLoading, refetch, isFetching } = useQuery<AiModel[]>({
    queryKey: ["/api/models"],
  });

  const form = useForm<AddModelForm>({
    resolver: zodResolver(addModelSchema),
    defaultValues: {
      name: "",
      vendor: "",
      parameters: "",
      modelType: "",
      avgKwhPerToken: "",
      avgCo2PerQuery: "",
    },
  });

  const addModelMutation = useMutation({
    mutationFn: async (data: AddModelForm) => {
      return apiRequest("POST", "/api/models", {
        ...data,
        avgKwhPerToken: data.avgKwhPerToken ? parseFloat(data.avgKwhPerToken) : null,
        avgCo2PerQuery: data.avgCo2PerQuery ? parseFloat(data.avgCo2PerQuery) : null,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/models"] });
      setDialogOpen(false);
      form.reset();
      toast({
        title: "Model added",
        description: "The AI model has been added to the database.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to add model. Please try again.",
        variant: "destructive",
      });
    },
  });

  const filteredModels = models?.filter((model) => {
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      if (
        !model.name.toLowerCase().includes(searchLower) &&
        !model.vendor.toLowerCase().includes(searchLower)
      ) {
        return false;
      }
    }

    if (filters.modelType) {
      if (model.modelType.toLowerCase() !== filters.modelType.toLowerCase()) {
        return false;
      }
    }

    return true;
  }) || [];

  const chartData = filteredModels?.slice(0, 10).map((model) => ({
    name: model.name,
    kwhPerToken: model.avgKwhPerToken || 0,
    co2PerQuery: model.avgCo2PerQuery || 0,
  }));

  const onSubmit = (data: AddModelForm) => {
    addModelMutation.mutate(data);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="text-models-title">
            AI Model Comparison
          </h1>
          <p className="text-muted-foreground mt-1">
            Compare environmental impact metrics across AI models
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => refetch()}
            disabled={isFetching}
            data-testid="button-refresh-models"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isFetching ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" data-testid="button-add-model">
                <Plus className="h-4 w-4 mr-2" />
                Add Model
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add AI Model</DialogTitle>
                <DialogDescription>
                  Add a new AI model to track its environmental impact
                </DialogDescription>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Model Name</FormLabel>
                        <FormControl>
                          <Input placeholder="GPT-4" {...field} data-testid="input-model-name" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="vendor"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Vendor</FormLabel>
                        <FormControl>
                          <Input placeholder="OpenAI" {...field} data-testid="input-model-vendor" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="parameters"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Parameters</FormLabel>
                        <FormControl>
                          <Input placeholder="175B" {...field} data-testid="input-model-params" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="modelType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Model Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-model-type-form">
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="LLM">LLM</SelectItem>
                            <SelectItem value="Image">Image Generation</SelectItem>
                            <SelectItem value="Video">Video Generation</SelectItem>
                            <SelectItem value="Audio">Audio/Speech</SelectItem>
                            <SelectItem value="Multimodal">Multimodal</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="avgKwhPerToken"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>kWh per Token</FormLabel>
                          <FormControl>
                            <Input type="number" step="0.000001" placeholder="0.000001" {...field} data-testid="input-model-kwh" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="avgCo2PerQuery"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>CO2 per Query (g)</FormLabel>
                          <FormControl>
                            <Input type="number" step="0.01" placeholder="0.5" {...field} data-testid="input-model-co2" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <DialogFooter>
                    <Button type="submit" disabled={addModelMutation.isPending} data-testid="button-submit-model">
                      {addModelMutation.isPending ? "Adding..." : "Add Model"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <SearchFilters
        filters={filters}
        onFiltersChange={setFilters}
        placeholder="Search by model name or vendor..."
      />

      {isLoading ? (
        <div className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <Skeleton className="h-[300px] w-full" />
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <Skeleton className="h-[400px] w-full" />
            </CardContent>
          </Card>
        </div>
      ) : filteredModels && filteredModels.length > 0 ? (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Impact Comparison</CardTitle>
              <CardDescription>
                Energy consumption and CO2 emissions by model
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis
                      dataKey="name"
                      className="text-xs"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                      angle={-45}
                      textAnchor="end"
                      height={80}
                    />
                    <YAxis
                      yAxisId="left"
                      className="text-xs"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <YAxis
                      yAxisId="right"
                      orientation="right"
                      className="text-xs"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        borderColor: 'hsl(var(--border))',
                        borderRadius: '0.375rem',
                      }}
                    />
                    <Legend />
                    <Bar
                      yAxisId="left"
                      dataKey="kwhPerToken"
                      name="kWh per Token"
                      fill="hsl(var(--chart-1))"
                      radius={[4, 4, 0, 0]}
                    />
                    <Bar
                      yAxisId="right"
                      dataKey="co2PerQuery"
                      name="CO2 per Query (g)"
                      fill="hsl(var(--chart-2))"
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Model Database</CardTitle>
              <CardDescription>
                {filteredModels.length} model{filteredModels.length !== 1 ? 's' : ''} tracked
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ModelTable models={filteredModels} />
            </CardContent>
          </Card>
        </div>
      ) : (
        <EmptyState
          icon={BarChart3}
          title="No models found"
          description={
            filters.search || filters.modelType
              ? "Try adjusting your search or filters"
              : "Add your first AI model to start tracking environmental impact"
          }
          action={{
            label: "Add Model",
            onClick: () => setDialogOpen(true),
          }}
          testId="empty-models"
        />
      )}
    </div>
  );
}
