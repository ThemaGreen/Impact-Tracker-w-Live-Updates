import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { ArrowLeft, ExternalLink, FileText, Calendar, Users, Quote, Check, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import type { ResearchPaper, ImpactMetric, AiModel } from "@shared/schema";

interface PaperWithMetrics extends ResearchPaper {
  metrics?: (ImpactMetric & { model?: AiModel })[];
}

export default function PaperDetailPage() {
  const [, params] = useRoute("/papers/:id");
  const paperId = params?.id;

  const { data: paper, isLoading } = useQuery<PaperWithMetrics>({
    queryKey: ["/api/papers", paperId],
    enabled: !!paperId,
  });

  const formatDate = (date: string | null) => {
    if (!date) return "Unknown";
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Skeleton className="h-9 w-24" />
        </div>
        <div className="space-y-4">
          <Skeleton className="h-10 w-3/4" />
          <Skeleton className="h-6 w-1/2" />
        </div>
        <Card>
          <CardContent className="p-6 space-y-4">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!paper) {
    return (
      <div className="space-y-6">
        <Link href="/papers">
          <Button variant="ghost" size="sm">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Papers
          </Button>
        </Link>
        <div className="text-center py-12">
          <AlertCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <h2 className="text-xl font-semibold">Paper not found</h2>
          <p className="text-muted-foreground mt-1">
            The paper you're looking for doesn't exist or has been removed.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Link href="/papers">
        <Button variant="ghost" size="sm" data-testid="button-back-papers">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Papers
        </Button>
      </Link>

      <div className="space-y-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <h1 className="text-2xl font-bold tracking-tight leading-snug" data-testid="text-paper-detail-title">
              {paper.title}
            </h1>
            <div className="flex items-center gap-2 mt-2 text-muted-foreground">
              <Users className="h-4 w-4" />
              <span data-testid="text-paper-detail-authors">{paper.authors}</span>
            </div>
          </div>
          {paper.isVerified && (
            <Badge variant="default" className="shrink-0">
              <Check className="h-3 w-3 mr-1" />
              Verified
            </Badge>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-4 text-sm">
          {paper.venue && (
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <FileText className="h-4 w-4" />
              <span className="font-medium">{paper.venue}</span>
            </div>
          )}
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Calendar className="h-4 w-4" />
            <span>{formatDate(paper.publicationDate)}</span>
          </div>
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Quote className="h-4 w-4" />
            <span className="font-mono">{paper.citationCount || 0} citations</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {paper.scholarUrl && (
            <Button variant="outline" size="sm" asChild>
              <a href={paper.scholarUrl} target="_blank" rel="noopener noreferrer" data-testid="link-scholar">
                <ExternalLink className="h-4 w-4 mr-1.5" />
                Google Scholar
              </a>
            </Button>
          )}
          {paper.pdfUrl && (
            <Button variant="outline" size="sm" asChild>
              <a href={paper.pdfUrl} target="_blank" rel="noopener noreferrer" data-testid="link-pdf">
                <FileText className="h-4 w-4 mr-1.5" />
                View PDF
              </a>
            </Button>
          )}
          {paper.doi && (
            <Button variant="outline" size="sm" asChild>
              <a href={`https://doi.org/${paper.doi}`} target="_blank" rel="noopener noreferrer" data-testid="link-doi">
                DOI: {paper.doi}
              </a>
            </Button>
          )}
        </div>
      </div>

      <Tabs defaultValue="abstract" className="space-y-4">
        <TabsList>
          <TabsTrigger value="abstract" data-testid="tab-abstract">Abstract</TabsTrigger>
          <TabsTrigger value="metrics" data-testid="tab-metrics">Extracted Metrics</TabsTrigger>
          <TabsTrigger value="citation" data-testid="tab-citation">Citation</TabsTrigger>
        </TabsList>

        <TabsContent value="abstract">
          <Card>
            <CardHeader>
              <CardTitle>Abstract</CardTitle>
            </CardHeader>
            <CardContent>
              {paper.abstract ? (
                <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap" data-testid="text-abstract">
                  {paper.abstract}
                </p>
              ) : (
                <p className="text-muted-foreground italic">
                  No abstract available for this paper.
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="metrics">
          <Card>
            <CardHeader>
              <CardTitle>Extracted Impact Metrics</CardTitle>
              <CardDescription>
                Environmental impact data extracted from this research paper
              </CardDescription>
            </CardHeader>
            <CardContent>
              {paper.metrics && paper.metrics.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Model</TableHead>
                      <TableHead>Metric Type</TableHead>
                      <TableHead>Value</TableHead>
                      <TableHead>Unit</TableHead>
                      <TableHead>Confidence</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paper.metrics.map((metric) => (
                      <TableRow key={metric.id}>
                        <TableCell className="font-medium">
                          {metric.model?.name || "General"}
                        </TableCell>
                        <TableCell>{metric.metricType}</TableCell>
                        <TableCell className="font-mono">{metric.value}</TableCell>
                        <TableCell>{metric.unit}</TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {metric.confidenceLevel || "Unknown"}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <AlertCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No metrics have been extracted from this paper yet.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="citation">
          <Card>
            <CardHeader>
              <CardTitle>Citation</CardTitle>
              <CardDescription>Copy this citation for your research</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-muted rounded-md font-mono text-sm" data-testid="text-citation">
                {paper.authors} ({paper.publicationDate ? new Date(paper.publicationDate).getFullYear() : "n.d."}). 
                {paper.title}. 
                {paper.venue && <>{paper.venue}. </>}
                {paper.doi && <>https://doi.org/{paper.doi}</>}
              </div>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => {
                  const citation = `${paper.authors} (${paper.publicationDate ? new Date(paper.publicationDate).getFullYear() : "n.d."}). ${paper.title}. ${paper.venue || ""} ${paper.doi ? `https://doi.org/${paper.doi}` : ""}`;
                  navigator.clipboard.writeText(citation);
                }}
                data-testid="button-copy-citation"
              >
                Copy Citation
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
