import { useQuery } from "@tanstack/react-query";
import { FileText, BarChart3, Zap, Leaf, TrendingUp, ArrowRight } from "lucide-react";
import { StatsCard } from "@/components/stats-card";
import { PaperCard } from "@/components/paper-card";
import { TimelineChart } from "@/components/timeline-chart";
import { DashboardSkeleton, PaperCardSkeleton } from "@/components/loading-skeleton";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Link } from "wouter";
import type { ResearchPaper, AiModel, ImpactMetric } from "@shared/schema";

interface DashboardStats {
  totalPapers: number;
  totalModels: number;
  totalMetrics: number;
  avgCitationsPerPaper: number;
  papersTrend: number;
  metricsTrend: number;
}

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/stats"],
  });

  const { data: recentPapers, isLoading: papersLoading } = useQuery<ResearchPaper[]>({
    queryKey: ["/api/papers", "recent"],
  });

  const { data: topCitedPapers } = useQuery<ResearchPaper[]>({
    queryKey: ["/api/papers", "top-cited"],
  });

  const { data: timelineData } = useQuery<{ date: string; papers: number; avgCitations: number; avgCo2Estimate: number }[]>({
    queryKey: ["/api/timeline"],
  });

  if (statsLoading) {
    return <DashboardSkeleton />;
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight" data-testid="text-dashboard-title">
          Research Dashboard
        </h1>
        <p className="text-muted-foreground mt-1">
          Track AI environmental impact research from academic sources
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Research Papers"
          value={stats?.totalPapers || 0}
          description="Papers in database"
          icon={FileText}
          trend={stats?.papersTrend ? { value: stats.papersTrend, isPositive: true } : undefined}
          testId="stats-papers"
        />
        <StatsCard
          title="AI Models Tracked"
          value={stats?.totalModels || 0}
          description="Models with impact data"
          icon={BarChart3}
          testId="stats-models"
        />
        <StatsCard
          title="Impact Metrics"
          value={stats?.totalMetrics || 0}
          description="Data points extracted"
          icon={Zap}
          trend={stats?.metricsTrend ? { value: stats.metricsTrend, isPositive: true } : undefined}
          testId="stats-metrics"
        />
        <StatsCard
          title="Avg Citations"
          value={stats?.avgCitationsPerPaper?.toFixed(1) || "0"}
          description="Per research paper"
          icon={TrendingUp}
          testId="stats-citations"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          {timelineData && timelineData.length > 0 ? (
            <TimelineChart
              data={timelineData}
              title="Research Publication Timeline"
              description="Number of papers published and their average citations over time"
            />
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Research Timeline</CardTitle>
                <CardDescription>Publication trends will appear here as data is collected</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[350px] flex items-center justify-center text-muted-foreground">
                  <div className="text-center">
                    <Leaf className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No timeline data available yet</p>
                    <p className="text-sm mt-1">Start by adding research papers to the database</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4">
            <div>
              <CardTitle>Top Cited Papers</CardTitle>
              <CardDescription>Most influential research</CardDescription>
            </div>
            <Link href="/papers">
              <Button variant="ghost" size="sm">
                View all
                <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent className="space-y-4">
            {papersLoading ? (
              <>
                <PaperCardSkeleton />
              </>
            ) : topCitedPapers && topCitedPapers.length > 0 ? (
              topCitedPapers.slice(0, 2).map((paper) => (
                <PaperCard key={paper.id} paper={paper} showMetrics={false} />
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <FileText className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No papers yet</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <div>
            <CardTitle>Recent Research</CardTitle>
            <CardDescription>Latest papers added to the database</CardDescription>
          </div>
          <Link href="/papers">
            <Button variant="ghost" size="sm">
              View all papers
              <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          {papersLoading ? (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <PaperCardSkeleton />
              <PaperCardSkeleton />
              <PaperCardSkeleton />
            </div>
          ) : recentPapers && recentPapers.length > 0 ? (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {recentPapers.slice(0, 6).map((paper) => (
                <PaperCard key={paper.id} paper={paper} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="font-medium">No research papers yet</p>
              <p className="text-sm mt-1">Use the Search Scholar tool to find and import papers</p>
              <Link href="/search">
                <Button variant="secondary" className="mt-4">
                  Search Google Scholar
                </Button>
              </Link>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
