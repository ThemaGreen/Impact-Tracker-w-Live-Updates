import { useQuery } from "@tanstack/react-query";
import { Clock, TrendingUp, FileText, BarChart3 } from "lucide-react";
import { TimelineChart } from "@/components/timeline-chart";
import { StatsCard } from "@/components/stats-card";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/empty-state";
import type { ResearchPaper } from "@shared/schema";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

interface TimelineDataPoint {
  date: string;
  papers: number;
  avgCitations: number;
  avgCo2Estimate: number;
}

interface TimelineStats {
  totalPapers: number;
  yearsSpanned: number;
  peakYear: string;
  avgGrowthRate: number;
}

export default function TimelinePage() {
  const { data: timelineData, isLoading: timelineLoading } = useQuery<TimelineDataPoint[]>({
    queryKey: ["/api/timeline"],
  });

  const { data: stats, isLoading: statsLoading } = useQuery<TimelineStats>({
    queryKey: ["/api/timeline/stats"],
  });

  const { data: recentPapers, isLoading: papersLoading } = useQuery<ResearchPaper[]>({
    queryKey: ["/api/papers", "recent"],
  });

  const isLoading = timelineLoading || statsLoading;

  const co2TrendData = timelineData?.map((point) => ({
    date: point.date,
    avgCo2: point.avgCo2Estimate,
  }));

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-96" />
        </div>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
        </div>
        <Skeleton className="h-[400px]" />
      </div>
    );
  }

  if (!timelineData || timelineData.length === 0) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="text-timeline-title">
            Research Timeline
          </h1>
          <p className="text-muted-foreground mt-1">
            Track how AI environmental impact research has evolved over time
          </p>
        </div>
        <EmptyState
          icon={Clock}
          title="No timeline data yet"
          description="Add research papers with publication dates to see the evolution of AI impact research over time"
          action={{
            label: "Search Google Scholar",
            onClick: () => window.location.href = "/search",
          }}
          testId="empty-timeline"
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight" data-testid="text-timeline-title">
          Research Timeline
        </h1>
        <p className="text-muted-foreground mt-1">
          Track how AI environmental impact research has evolved over time
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Total Papers"
          value={stats?.totalPapers || 0}
          description="In timeline"
          icon={FileText}
          testId="stats-timeline-papers"
        />
        <StatsCard
          title="Years Spanned"
          value={stats?.yearsSpanned || 0}
          description="Research period"
          icon={Clock}
          testId="stats-years"
        />
        <StatsCard
          title="Peak Year"
          value={stats?.peakYear || "—"}
          description="Most publications"
          icon={TrendingUp}
          testId="stats-peak"
        />
        <StatsCard
          title="Avg Growth"
          value={`${stats?.avgGrowthRate?.toFixed(1) || 0}%`}
          description="Year over year"
          icon={BarChart3}
          testId="stats-growth"
        />
      </div>

      <TimelineChart
        data={timelineData}
        title="Publication Volume Over Time"
        description="Number of papers published and their average citations by year"
      />

      {co2TrendData && co2TrendData.some(d => d.avgCo2 > 0) && (
        <Card>
          <CardHeader>
            <CardTitle>CO2 Estimate Trends</CardTitle>
            <CardDescription>
              How reported CO2 emissions estimates have changed over time
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={co2TrendData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis
                    dataKey="date"
                    className="text-xs"
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <YAxis
                    className="text-xs"
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      borderColor: 'hsl(var(--border))',
                      borderRadius: '0.375rem',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="avgCo2"
                    name="Avg CO2 (g/query)"
                    stroke="hsl(var(--chart-3))"
                    fill="hsl(var(--chart-3))"
                    fillOpacity={0.2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Recent Additions</CardTitle>
          <CardDescription>Latest papers added to the timeline</CardDescription>
        </CardHeader>
        <CardContent>
          {papersLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
            </div>
          ) : recentPapers && recentPapers.length > 0 ? (
            <div className="space-y-4">
              {recentPapers.slice(0, 5).map((paper) => (
                <div
                  key={paper.id}
                  className="flex items-start gap-4 p-4 rounded-md border"
                  data-testid={`timeline-paper-${paper.id}`}
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
                    <FileText className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm line-clamp-1">{paper.title}</h4>
                    <p className="text-xs text-muted-foreground mt-1">{paper.authors}</p>
                    <div className="flex items-center gap-2 mt-2">
                      {paper.publicationDate && (
                        <Badge variant="outline" className="text-xs">
                          {new Date(paper.publicationDate).getFullYear()}
                        </Badge>
                      )}
                      <Badge variant="secondary" className="text-xs font-mono">
                        {paper.citationCount || 0} citations
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No papers in the timeline yet</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
