import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, FileJson, FileText, FileSpreadsheet, Check } from "lucide-react";
import { useState } from "react";

interface ExportPanelProps {
  papersCount: number;
  modelsCount: number;
  metricsCount: number;
  onExport: (format: "csv" | "json" | "bibtex") => void;
  isExporting?: boolean;
}

export function ExportPanel({
  papersCount,
  modelsCount,
  metricsCount,
  onExport,
  isExporting = false,
}: ExportPanelProps) {
  const [lastExported, setLastExported] = useState<string | null>(null);

  const handleExport = (format: "csv" | "json" | "bibtex") => {
    onExport(format);
    setLastExported(format);
    setTimeout(() => setLastExported(null), 3000);
  };

  return (
    <Card data-testid="card-export-panel">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Download className="h-5 w-5" />
          Export Data
        </CardTitle>
        <CardDescription>
          Download research data in your preferred format
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div className="p-4 bg-card rounded-md border">
            <p className="text-2xl font-bold font-mono" data-testid="text-export-papers-count">
              {papersCount}
            </p>
            <p className="text-sm text-muted-foreground">Papers</p>
          </div>
          <div className="p-4 bg-card rounded-md border">
            <p className="text-2xl font-bold font-mono" data-testid="text-export-models-count">
              {modelsCount}
            </p>
            <p className="text-sm text-muted-foreground">Models</p>
          </div>
          <div className="p-4 bg-card rounded-md border">
            <p className="text-2xl font-bold font-mono" data-testid="text-export-metrics-count">
              {metricsCount}
            </p>
            <p className="text-sm text-muted-foreground">Metrics</p>
          </div>
        </div>

        <div className="space-y-3">
          <h4 className="font-medium text-sm">Export Format</h4>
          
          <div className="grid gap-3">
            <Button
              variant="outline"
              className="justify-start h-auto py-3"
              onClick={() => handleExport("csv")}
              disabled={isExporting}
              data-testid="button-panel-export-csv"
            >
              <FileSpreadsheet className="h-5 w-5 mr-3 text-green-600 dark:text-green-400" />
              <div className="flex-1 text-left">
                <p className="font-medium">CSV Spreadsheet</p>
                <p className="text-xs text-muted-foreground">
                  Compatible with Excel, Google Sheets
                </p>
              </div>
              {lastExported === "csv" && (
                <Badge variant="secondary" className="ml-2">
                  <Check className="h-3 w-3 mr-1" />
                  Exported
                </Badge>
              )}
            </Button>

            <Button
              variant="outline"
              className="justify-start h-auto py-3"
              onClick={() => handleExport("json")}
              disabled={isExporting}
              data-testid="button-panel-export-json"
            >
              <FileJson className="h-5 w-5 mr-3 text-blue-600 dark:text-blue-400" />
              <div className="flex-1 text-left">
                <p className="font-medium">JSON Data</p>
                <p className="text-xs text-muted-foreground">
                  For developers and data analysis
                </p>
              </div>
              {lastExported === "json" && (
                <Badge variant="secondary" className="ml-2">
                  <Check className="h-3 w-3 mr-1" />
                  Exported
                </Badge>
              )}
            </Button>

            <Button
              variant="outline"
              className="justify-start h-auto py-3"
              onClick={() => handleExport("bibtex")}
              disabled={isExporting}
              data-testid="button-panel-export-bibtex"
            >
              <FileText className="h-5 w-5 mr-3 text-purple-600 dark:text-purple-400" />
              <div className="flex-1 text-left">
                <p className="font-medium">BibTeX Citations</p>
                <p className="text-xs text-muted-foreground">
                  For academic papers and LaTeX
                </p>
              </div>
              {lastExported === "bibtex" && (
                <Badge variant="secondary" className="ml-2">
                  <Check className="h-3 w-3 mr-1" />
                  Exported
                </Badge>
              )}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
