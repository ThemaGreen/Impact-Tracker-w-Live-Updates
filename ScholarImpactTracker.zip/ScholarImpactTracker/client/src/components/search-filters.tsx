import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, X, Filter } from "lucide-react";

export interface FilterState {
  search: string;
  modelType: string;
  dateRange: string;
  metricType: string;
  citationThreshold: string;
}

interface SearchFiltersProps {
  filters: FilterState;
  onFiltersChange: (filters: FilterState) => void;
  placeholder?: string;
}

export function SearchFilters({
  filters,
  onFiltersChange,
  placeholder = "Search papers, models, or metrics...",
}: SearchFiltersProps) {
  const [showFilters, setShowFilters] = useState(false);

  const updateFilter = (key: keyof FilterState, value: string) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  const clearFilter = (key: keyof FilterState) => {
    onFiltersChange({ ...filters, [key]: "" });
  };

  const clearAllFilters = () => {
    onFiltersChange({
      search: "",
      modelType: "",
      dateRange: "",
      metricType: "",
      citationThreshold: "",
    });
  };

  const activeFilters = Object.entries(filters).filter(
    ([key, value]) => value && key !== "search"
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            type="search"
            placeholder={placeholder}
            value={filters.search}
            onChange={(e) => updateFilter("search", e.target.value)}
            className="pl-10 text-base"
            data-testid="input-search"
          />
        </div>
        <Button
          variant={showFilters ? "secondary" : "outline"}
          onClick={() => setShowFilters(!showFilters)}
          data-testid="button-toggle-filters"
        >
          <Filter className="h-4 w-4 mr-2" />
          Filters
          {activeFilters.length > 0 && (
            <Badge variant="default" className="ml-2">
              {activeFilters.length}
            </Badge>
          )}
        </Button>
      </div>

      {showFilters && (
        <div className="flex flex-wrap items-center gap-3 p-4 bg-card rounded-md border">
          <Select
            value={filters.modelType}
            onValueChange={(value) => updateFilter("modelType", value)}
          >
            <SelectTrigger className="w-[160px]" data-testid="select-model-type">
              <SelectValue placeholder="Model Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="llm">LLM</SelectItem>
              <SelectItem value="image">Image Generation</SelectItem>
              <SelectItem value="video">Video Generation</SelectItem>
              <SelectItem value="audio">Audio/Speech</SelectItem>
              <SelectItem value="multimodal">Multimodal</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={filters.dateRange}
            onValueChange={(value) => updateFilter("dateRange", value)}
          >
            <SelectTrigger className="w-[160px]" data-testid="select-date-range">
              <SelectValue placeholder="Date Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2024">2024</SelectItem>
              <SelectItem value="2023">2023</SelectItem>
              <SelectItem value="2022">2022</SelectItem>
              <SelectItem value="2021">2021</SelectItem>
              <SelectItem value="older">Before 2021</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={filters.metricType}
            onValueChange={(value) => updateFilter("metricType", value)}
          >
            <SelectTrigger className="w-[180px]" data-testid="select-metric-type">
              <SelectValue placeholder="Metric Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="kwh_per_token">kWh per Token</SelectItem>
              <SelectItem value="co2_per_query">CO2 per Query</SelectItem>
              <SelectItem value="training_energy">Training Energy</SelectItem>
              <SelectItem value="inference_energy">Inference Energy</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={filters.citationThreshold}
            onValueChange={(value) => updateFilter("citationThreshold", value)}
          >
            <SelectTrigger className="w-[180px]" data-testid="select-citations">
              <SelectValue placeholder="Min Citations" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="0">Any citations</SelectItem>
              <SelectItem value="10">10+ citations</SelectItem>
              <SelectItem value="50">50+ citations</SelectItem>
              <SelectItem value="100">100+ citations</SelectItem>
              <SelectItem value="500">500+ citations</SelectItem>
            </SelectContent>
          </Select>

          {activeFilters.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearAllFilters}
              className="text-muted-foreground"
              data-testid="button-clear-filters"
            >
              <X className="h-4 w-4 mr-1" />
              Clear all
            </Button>
          )}
        </div>
      )}

      {activeFilters.length > 0 && (
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-sm text-muted-foreground">Active filters:</span>
          {activeFilters.map(([key, value]) => (
            <Badge
              key={key}
              variant="secondary"
              className="cursor-pointer"
              onClick={() => clearFilter(key as keyof FilterState)}
              data-testid={`badge-filter-${key}`}
            >
              {key}: {value}
              <X className="h-3 w-3 ml-1" />
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
}
