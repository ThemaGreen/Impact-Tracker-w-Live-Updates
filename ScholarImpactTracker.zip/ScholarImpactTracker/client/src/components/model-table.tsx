import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, ExternalLink } from "lucide-react";
import type { AiModel } from "@shared/schema";
import { Link } from "wouter";
import { useState } from "react";

interface ModelTableProps {
  models: AiModel[];
}

type SortField = "name" | "parameters" | "avgKwhPerToken" | "avgCo2PerQuery";
type SortOrder = "asc" | "desc";

export function ModelTable({ models }: ModelTableProps) {
  const [sortField, setSortField] = useState<SortField>("name");
  const [sortOrder, setSortOrder] = useState<SortOrder>("asc");

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("asc");
    }
  };

  const sortedModels = [...models].sort((a, b) => {
    let aValue: string | number | null = null;
    let bValue: string | number | null = null;

    switch (sortField) {
      case "name":
        aValue = a.name;
        bValue = b.name;
        break;
      case "parameters":
        aValue = a.parameters || "";
        bValue = b.parameters || "";
        break;
      case "avgKwhPerToken":
        aValue = a.avgKwhPerToken || 0;
        bValue = b.avgKwhPerToken || 0;
        break;
      case "avgCo2PerQuery":
        aValue = a.avgCo2PerQuery || 0;
        bValue = b.avgCo2PerQuery || 0;
        break;
    }

    if (typeof aValue === "string" && typeof bValue === "string") {
      return sortOrder === "asc"
        ? aValue.localeCompare(bValue)
        : bValue.localeCompare(aValue);
    }

    if (typeof aValue === "number" && typeof bValue === "number") {
      return sortOrder === "asc" ? aValue - bValue : bValue - aValue;
    }

    return 0;
  });

  const formatNumber = (num: number | null, decimals = 6) => {
    if (num === null || num === undefined) return "—";
    return num.toFixed(decimals);
  };

  const getModelTypeBadgeVariant = (type: string) => {
    switch (type.toLowerCase()) {
      case "llm":
        return "default";
      case "image":
        return "secondary";
      case "video":
        return "outline";
      default:
        return "secondary";
    }
  };

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[200px]">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("name")}
                className="-ml-3"
                data-testid="button-sort-name"
              >
                Model Name
                <ArrowUpDown className="ml-2 h-4 w-4" />
              </Button>
            </TableHead>
            <TableHead>Vendor</TableHead>
            <TableHead>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("parameters")}
                className="-ml-3"
                data-testid="button-sort-parameters"
              >
                Parameters
                <ArrowUpDown className="ml-2 h-4 w-4" />
              </Button>
            </TableHead>
            <TableHead>Type</TableHead>
            <TableHead>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("avgKwhPerToken")}
                className="-ml-3"
                data-testid="button-sort-kwh"
              >
                kWh/Token
                <ArrowUpDown className="ml-2 h-4 w-4" />
              </Button>
            </TableHead>
            <TableHead>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("avgCo2PerQuery")}
                className="-ml-3"
                data-testid="button-sort-co2"
              >
                CO2/Query (g)
                <ArrowUpDown className="ml-2 h-4 w-4" />
              </Button>
            </TableHead>
            <TableHead className="text-right">Last Updated</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedModels.length === 0 ? (
            <TableRow>
              <TableCell colSpan={7} className="h-24 text-center">
                <div className="text-muted-foreground">
                  No models found. Add your first AI model to get started.
                </div>
              </TableCell>
            </TableRow>
          ) : (
            sortedModels.map((model) => (
              <TableRow key={model.id} data-testid={`row-model-${model.id}`}>
                <TableCell className="font-medium">
                  <Link href={`/models/${model.id}`} className="hover:text-primary transition-colors">
                    {model.name}
                  </Link>
                </TableCell>
                <TableCell className="text-muted-foreground">
                  {model.vendor}
                </TableCell>
                <TableCell className="font-mono text-sm">
                  {model.parameters || "—"}
                </TableCell>
                <TableCell>
                  <Badge variant={getModelTypeBadgeVariant(model.modelType)}>
                    {model.modelType}
                  </Badge>
                </TableCell>
                <TableCell className="font-mono text-sm">
                  {formatNumber(model.avgKwhPerToken)}
                </TableCell>
                <TableCell className="font-mono text-sm">
                  {formatNumber(model.avgCo2PerQuery, 2)}
                </TableCell>
                <TableCell className="text-right text-muted-foreground text-sm">
                  {model.lastUpdated
                    ? new Date(model.lastUpdated).toLocaleDateString()
                    : "—"}
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}
