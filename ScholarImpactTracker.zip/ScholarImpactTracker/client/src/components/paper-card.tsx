import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, FileText, Quote, Calendar, Users } from "lucide-react";
import type { ResearchPaper } from "@shared/schema";
import { Link } from "wouter";

interface PaperCardProps {
  paper: ResearchPaper;
  showMetrics?: boolean;
}

export function PaperCard({ paper, showMetrics = true }: PaperCardProps) {
  const formatDate = (date: string | null) => {
    if (!date) return "Unknown";
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
    });
  };

  return (
    <Card className="hover-elevate transition-all duration-200" data-testid={`card-paper-${paper.id}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 space-y-1">
            <Link href={`/papers/${paper.id}`}>
              <h3 className="font-semibold text-base leading-snug line-clamp-2 hover:text-primary transition-colors cursor-pointer" data-testid={`text-paper-title-${paper.id}`}>
                {paper.title}
              </h3>
            </Link>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Users className="h-3.5 w-3.5" />
              <span className="line-clamp-1" data-testid={`text-paper-authors-${paper.id}`}>{paper.authors}</span>
            </div>
          </div>
          {paper.isVerified && (
            <Badge variant="secondary" className="shrink-0">
              Verified
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {paper.abstract && (
          <p className="text-sm text-muted-foreground line-clamp-3">
            {paper.abstract}
          </p>
        )}
        
        <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
          {paper.venue && (
            <div className="flex items-center gap-1.5">
              <FileText className="h-3.5 w-3.5" />
              <span className="font-medium">{paper.venue}</span>
            </div>
          )}
          <div className="flex items-center gap-1.5">
            <Calendar className="h-3.5 w-3.5" />
            <span>{formatDate(paper.publicationDate)}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Quote className="h-3.5 w-3.5" />
            <span className="font-mono">{paper.citationCount || 0} citations</span>
          </div>
        </div>

        {showMetrics && (
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className="font-mono text-xs">
              Energy Data
            </Badge>
            <Badge variant="outline" className="font-mono text-xs">
              CO2 Emissions
            </Badge>
          </div>
        )}

        <div className="flex items-center gap-2 pt-2">
          <Link href={`/papers/${paper.id}`}>
            <Button variant="secondary" size="sm" data-testid={`button-view-paper-${paper.id}`}>
              View Details
            </Button>
          </Link>
          {paper.scholarUrl && (
            <Button variant="ghost" size="sm" asChild>
              <a
                href={paper.scholarUrl}
                target="_blank"
                rel="noopener noreferrer"
                data-testid={`link-scholar-${paper.id}`}
              >
                <ExternalLink className="h-4 w-4 mr-1.5" />
                Scholar
              </a>
            </Button>
          )}
          {paper.pdfUrl && (
            <Button variant="ghost" size="sm" asChild>
              <a
                href={paper.pdfUrl}
                target="_blank"
                rel="noopener noreferrer"
                data-testid={`link-pdf-${paper.id}`}
              >
                <FileText className="h-4 w-4 mr-1.5" />
                PDF
              </a>
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
