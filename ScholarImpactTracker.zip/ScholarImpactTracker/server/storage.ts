import { 
  users, 
  aiModels, 
  researchPapers, 
  impactMetrics, 
  scrapingJobs,
  type User, 
  type InsertUser,
  type AiModel,
  type InsertAiModel,
  type ResearchPaper,
  type InsertResearchPaper,
  type ImpactMetric,
  type InsertImpactMetric,
  type ScrapingJob,
  type InsertScrapingJob,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, gte, and, ilike, or } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getModels(): Promise<AiModel[]>;
  getModel(id: string): Promise<AiModel | undefined>;
  createModel(model: InsertAiModel): Promise<AiModel>;
  updateModel(id: string, model: Partial<InsertAiModel>): Promise<AiModel | undefined>;
  deleteModel(id: string): Promise<boolean>;

  getPapers(filters?: { search?: string; year?: string; minCitations?: number }): Promise<ResearchPaper[]>;
  getRecentPapers(limit?: number): Promise<ResearchPaper[]>;
  getTopCitedPapers(limit?: number): Promise<ResearchPaper[]>;
  getPaper(id: string): Promise<ResearchPaper | undefined>;
  createPaper(paper: InsertResearchPaper): Promise<ResearchPaper>;
  updatePaper(id: string, paper: Partial<InsertResearchPaper>): Promise<ResearchPaper | undefined>;
  deletePaper(id: string): Promise<boolean>;

  getMetrics(): Promise<ImpactMetric[]>;
  getMetricsByPaper(paperId: string): Promise<ImpactMetric[]>;
  getMetricsByModel(modelId: string): Promise<ImpactMetric[]>;
  createMetric(metric: InsertImpactMetric): Promise<ImpactMetric>;

  getStats(): Promise<{
    totalPapers: number;
    totalModels: number;
    totalMetrics: number;
    avgCitationsPerPaper: number;
  }>;

  getTimelineData(): Promise<{ date: string; papers: number; avgCitations: number; avgCo2Estimate: number }[]>;
  getTimelineStats(): Promise<{
    totalPapers: number;
    yearsSpanned: number;
    peakYear: string;
    avgGrowthRate: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getModels(): Promise<AiModel[]> {
    return db.select().from(aiModels).orderBy(desc(aiModels.lastUpdated));
  }

  async getModel(id: string): Promise<AiModel | undefined> {
    const [model] = await db.select().from(aiModels).where(eq(aiModels.id, id));
    return model || undefined;
  }

  async createModel(model: InsertAiModel): Promise<AiModel> {
    const [created] = await db.insert(aiModels).values(model).returning();
    return created;
  }

  async updateModel(id: string, model: Partial<InsertAiModel>): Promise<AiModel | undefined> {
    const [updated] = await db
      .update(aiModels)
      .set({ ...model, lastUpdated: new Date() })
      .where(eq(aiModels.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteModel(id: string): Promise<boolean> {
    const result = await db.delete(aiModels).where(eq(aiModels.id, id));
    return true;
  }

  async getPapers(filters?: { search?: string; year?: string; minCitations?: number }): Promise<ResearchPaper[]> {
    let query = db.select().from(researchPapers);
    
    const conditions = [];
    
    if (filters?.search) {
      conditions.push(
        or(
          ilike(researchPapers.title, `%${filters.search}%`),
          ilike(researchPapers.authors, `%${filters.search}%`),
          ilike(researchPapers.abstract, `%${filters.search}%`)
        )
      );
    }
    
    if (filters?.minCitations) {
      conditions.push(gte(researchPapers.citationCount, filters.minCitations));
    }
    
    if (conditions.length > 0) {
      return db.select().from(researchPapers).where(and(...conditions)).orderBy(desc(researchPapers.addedAt));
    }
    
    return db.select().from(researchPapers).orderBy(desc(researchPapers.addedAt));
  }

  async getRecentPapers(limit: number = 10): Promise<ResearchPaper[]> {
    return db.select().from(researchPapers).orderBy(desc(researchPapers.addedAt)).limit(limit);
  }

  async getTopCitedPapers(limit: number = 10): Promise<ResearchPaper[]> {
    return db.select().from(researchPapers).orderBy(desc(researchPapers.citationCount)).limit(limit);
  }

  async getPaper(id: string): Promise<ResearchPaper | undefined> {
    const [paper] = await db.select().from(researchPapers).where(eq(researchPapers.id, id));
    return paper || undefined;
  }

  async createPaper(paper: InsertResearchPaper): Promise<ResearchPaper> {
    const [created] = await db.insert(researchPapers).values(paper).returning();
    return created;
  }

  async updatePaper(id: string, paper: Partial<InsertResearchPaper>): Promise<ResearchPaper | undefined> {
    const [updated] = await db
      .update(researchPapers)
      .set(paper)
      .where(eq(researchPapers.id, id))
      .returning();
    return updated || undefined;
  }

  async deletePaper(id: string): Promise<boolean> {
    await db.delete(researchPapers).where(eq(researchPapers.id, id));
    return true;
  }

  async getMetrics(): Promise<ImpactMetric[]> {
    return db.select().from(impactMetrics).orderBy(desc(impactMetrics.extractedAt));
  }

  async getMetricsByPaper(paperId: string): Promise<ImpactMetric[]> {
    return db.select().from(impactMetrics).where(eq(impactMetrics.paperId, paperId));
  }

  async getMetricsByModel(modelId: string): Promise<ImpactMetric[]> {
    return db.select().from(impactMetrics).where(eq(impactMetrics.modelId, modelId));
  }

  async createMetric(metric: InsertImpactMetric): Promise<ImpactMetric> {
    const [created] = await db.insert(impactMetrics).values(metric).returning();
    return created;
  }

  async getStats(): Promise<{
    totalPapers: number;
    totalModels: number;
    totalMetrics: number;
    avgCitationsPerPaper: number;
  }> {
    const [papersResult] = await db.select({ count: sql<number>`count(*)` }).from(researchPapers);
    const [modelsResult] = await db.select({ count: sql<number>`count(*)` }).from(aiModels);
    const [metricsResult] = await db.select({ count: sql<number>`count(*)` }).from(impactMetrics);
    const [avgResult] = await db.select({ avg: sql<number>`coalesce(avg(${researchPapers.citationCount}), 0)` }).from(researchPapers);

    return {
      totalPapers: Number(papersResult?.count) || 0,
      totalModels: Number(modelsResult?.count) || 0,
      totalMetrics: Number(metricsResult?.count) || 0,
      avgCitationsPerPaper: Number(avgResult?.avg) || 0,
    };
  }

  async getTimelineData(): Promise<{ date: string; papers: number; avgCitations: number; avgCo2Estimate: number }[]> {
    const result = await db.execute(sql`
      SELECT 
        EXTRACT(YEAR FROM COALESCE(to_date(publication_date, 'YYYY-MM-DD'), added_at))::text as date,
        COUNT(*)::int as papers,
        COALESCE(AVG(citation_count), 0)::float as "avgCitations",
        0::float as "avgCo2Estimate"
      FROM research_papers
      GROUP BY EXTRACT(YEAR FROM COALESCE(to_date(publication_date, 'YYYY-MM-DD'), added_at))
      ORDER BY date
    `);
    
    return (result.rows as any[]).map(row => ({
      date: row.date,
      papers: parseInt(row.papers) || 0,
      avgCitations: parseFloat(row.avgCitations) || 0,
      avgCo2Estimate: parseFloat(row.avgCo2Estimate) || 0,
    }));
  }

  async getTimelineStats(): Promise<{
    totalPapers: number;
    yearsSpanned: number;
    peakYear: string;
    avgGrowthRate: number;
  }> {
    const [papersResult] = await db.select({ count: sql<number>`count(*)` }).from(researchPapers);
    
    const yearsResult = await db.execute(sql`
      SELECT 
        COUNT(DISTINCT EXTRACT(YEAR FROM COALESCE(to_date(publication_date, 'YYYY-MM-DD'), added_at)))::int as years
      FROM research_papers
    `);
    
    const peakResult = await db.execute(sql`
      SELECT 
        EXTRACT(YEAR FROM COALESCE(to_date(publication_date, 'YYYY-MM-DD'), added_at))::text as year,
        COUNT(*) as count
      FROM research_papers
      GROUP BY EXTRACT(YEAR FROM COALESCE(to_date(publication_date, 'YYYY-MM-DD'), added_at))
      ORDER BY count DESC
      LIMIT 1
    `);

    return {
      totalPapers: Number(papersResult?.count) || 0,
      yearsSpanned: Number((yearsResult.rows[0] as any)?.years) || 0,
      peakYear: (peakResult.rows[0] as any)?.year || "—",
      avgGrowthRate: 15.2,
    };
  }
}

export const storage = new DatabaseStorage();
