import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertAiModelSchema, 
  insertResearchPaperSchema, 
  insertImpactMetricSchema 
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json({
        ...stats,
        papersTrend: 12.5,
        metricsTrend: 8.3,
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  app.get("/api/papers", async (req, res) => {
    try {
      const { search, year, minCitations, type } = req.query;
      
      if (type === "recent") {
        const papers = await storage.getRecentPapers(10);
        return res.json(papers);
      }
      
      if (type === "top-cited") {
        const papers = await storage.getTopCitedPapers(10);
        return res.json(papers);
      }
      
      const papers = await storage.getPapers({
        search: search as string,
        year: year as string,
        minCitations: minCitations ? parseInt(minCitations as string) : undefined,
      });
      res.json(papers);
    } catch (error) {
      console.error("Error fetching papers:", error);
      res.status(500).json({ error: "Failed to fetch papers" });
    }
  });

  app.get("/api/papers/recent", async (req, res) => {
    try {
      const papers = await storage.getRecentPapers(10);
      res.json(papers);
    } catch (error) {
      console.error("Error fetching recent papers:", error);
      res.status(500).json({ error: "Failed to fetch recent papers" });
    }
  });

  app.get("/api/papers/top-cited", async (req, res) => {
    try {
      const papers = await storage.getTopCitedPapers(10);
      res.json(papers);
    } catch (error) {
      console.error("Error fetching top-cited papers:", error);
      res.status(500).json({ error: "Failed to fetch top-cited papers" });
    }
  });

  app.get("/api/papers/:id", async (req, res) => {
    try {
      const paper = await storage.getPaper(req.params.id);
      if (!paper) {
        return res.status(404).json({ error: "Paper not found" });
      }
      
      const metrics = await storage.getMetricsByPaper(req.params.id);
      res.json({ ...paper, metrics });
    } catch (error) {
      console.error("Error fetching paper:", error);
      res.status(500).json({ error: "Failed to fetch paper" });
    }
  });

  app.post("/api/papers", async (req, res) => {
    try {
      const validatedData = insertResearchPaperSchema.parse(req.body);
      const paper = await storage.createPaper(validatedData);
      res.status(201).json(paper);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid paper data", details: error.errors });
      }
      console.error("Error creating paper:", error);
      res.status(500).json({ error: "Failed to create paper" });
    }
  });

  app.patch("/api/papers/:id", async (req, res) => {
    try {
      const paper = await storage.updatePaper(req.params.id, req.body);
      if (!paper) {
        return res.status(404).json({ error: "Paper not found" });
      }
      res.json(paper);
    } catch (error) {
      console.error("Error updating paper:", error);
      res.status(500).json({ error: "Failed to update paper" });
    }
  });

  app.delete("/api/papers/:id", async (req, res) => {
    try {
      await storage.deletePaper(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting paper:", error);
      res.status(500).json({ error: "Failed to delete paper" });
    }
  });

  app.get("/api/models", async (req, res) => {
    try {
      const models = await storage.getModels();
      res.json(models);
    } catch (error) {
      console.error("Error fetching models:", error);
      res.status(500).json({ error: "Failed to fetch models" });
    }
  });

  app.get("/api/models/:id", async (req, res) => {
    try {
      const model = await storage.getModel(req.params.id);
      if (!model) {
        return res.status(404).json({ error: "Model not found" });
      }
      
      const metrics = await storage.getMetricsByModel(req.params.id);
      res.json({ ...model, metrics });
    } catch (error) {
      console.error("Error fetching model:", error);
      res.status(500).json({ error: "Failed to fetch model" });
    }
  });

  app.post("/api/models", async (req, res) => {
    try {
      const validatedData = insertAiModelSchema.parse(req.body);
      const model = await storage.createModel(validatedData);
      res.status(201).json(model);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid model data", details: error.errors });
      }
      console.error("Error creating model:", error);
      res.status(500).json({ error: "Failed to create model" });
    }
  });

  app.patch("/api/models/:id", async (req, res) => {
    try {
      const model = await storage.updateModel(req.params.id, req.body);
      if (!model) {
        return res.status(404).json({ error: "Model not found" });
      }
      res.json(model);
    } catch (error) {
      console.error("Error updating model:", error);
      res.status(500).json({ error: "Failed to update model" });
    }
  });

  app.delete("/api/models/:id", async (req, res) => {
    try {
      await storage.deleteModel(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting model:", error);
      res.status(500).json({ error: "Failed to delete model" });
    }
  });

  app.get("/api/metrics", async (req, res) => {
    try {
      const metrics = await storage.getMetrics();
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching metrics:", error);
      res.status(500).json({ error: "Failed to fetch metrics" });
    }
  });

  app.post("/api/metrics", async (req, res) => {
    try {
      const validatedData = insertImpactMetricSchema.parse(req.body);
      const metric = await storage.createMetric(validatedData);
      res.status(201).json(metric);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid metric data", details: error.errors });
      }
      console.error("Error creating metric:", error);
      res.status(500).json({ error: "Failed to create metric" });
    }
  });

  app.get("/api/timeline", async (req, res) => {
    try {
      const data = await storage.getTimelineData();
      res.json(data);
    } catch (error) {
      console.error("Error fetching timeline:", error);
      res.status(500).json({ error: "Failed to fetch timeline data" });
    }
  });

  app.get("/api/timeline/stats", async (req, res) => {
    try {
      const stats = await storage.getTimelineStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching timeline stats:", error);
      res.status(500).json({ error: "Failed to fetch timeline stats" });
    }
  });

  app.get("/api/export/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json({
        papersCount: stats.totalPapers,
        modelsCount: stats.totalModels,
        metricsCount: stats.totalMetrics,
      });
    } catch (error) {
      console.error("Error fetching export stats:", error);
      res.status(500).json({ error: "Failed to fetch export stats" });
    }
  });

  app.get("/api/scholar/search", async (req, res) => {
    try {
      const { query } = req.query;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ error: "Query parameter is required" });
      }

      const mockResults = generateMockScholarResults(query);
      res.json(mockResults);
    } catch (error) {
      console.error("Error searching scholar:", error);
      res.status(500).json({ error: "Failed to search Google Scholar" });
    }
  });

  return httpServer;
}

function generateMockScholarResults(query: string): any[] {
  const topics = [
    {
      title: `Energy Consumption of Large Language Models: A Comprehensive Analysis`,
      authors: "Smith, J., Johnson, A., Williams, R.",
      abstract: `This paper presents a comprehensive analysis of energy consumption patterns in large language models. We examine the computational requirements of various model architectures and their environmental implications. Our findings suggest that training costs scale superlinearly with model size, with GPT-4 class models consuming approximately 1,287 MWh during training.`,
      venue: "Nature Machine Intelligence",
      year: "2024",
      citationCount: 342,
    },
    {
      title: `Carbon Footprint of AI: From Training to Inference`,
      authors: "Chen, L., Kumar, P., Zhang, Y.",
      abstract: `We investigate the full lifecycle carbon footprint of artificial intelligence systems, from initial training through deployment and inference. Our analysis reveals that while training dominates energy use, the cumulative inference costs can exceed training within 6 months for popular models.`,
      venue: "Science",
      year: "2024",
      citationCount: 567,
    },
    {
      title: `Sustainable AI: Reducing the Environmental Impact of Machine Learning`,
      authors: "Martinez, E., Thompson, K., Lee, S.",
      abstract: `This study proposes methods for reducing the environmental impact of machine learning systems. We present techniques including efficient model architectures, optimized training procedures, and carbon-aware scheduling that can reduce energy consumption by up to 40%.`,
      venue: "Proceedings of NeurIPS",
      year: "2023",
      citationCount: 891,
    },
    {
      title: `Measuring the Carbon Intensity of AI in Practice`,
      authors: "Brown, M., Davis, T., Wilson, C.",
      abstract: `We develop a practical framework for measuring the carbon intensity of AI workloads in production environments. Our methodology accounts for hardware efficiency, data center location, and grid carbon intensity to provide accurate emissions estimates.`,
      venue: "ACM Computing Surveys",
      year: "2024",
      citationCount: 234,
    },
    {
      title: `The True Cost of ChatGPT: An Environmental Assessment`,
      authors: "Garcia, R., Kim, J., Patel, A.",
      abstract: `This paper provides an environmental assessment of ChatGPT and similar conversational AI systems. We estimate that each query consumes approximately 0.0003 kWh and produces 0.2-0.5 grams of CO2 equivalent, depending on the data center's energy mix.`,
      venue: "Environmental Research Letters",
      year: "2024",
      citationCount: 456,
    },
    {
      title: `Green AI: Towards Environmentally Sustainable Deep Learning`,
      authors: "Anderson, P., Taylor, M., Harris, L.",
      abstract: `We introduce Green AI, a paradigm shift towards environmentally sustainable deep learning practices. Our framework emphasizes efficiency metrics alongside accuracy, promoting the development of models that achieve competitive performance with minimal environmental impact.`,
      venue: "Communications of the ACM",
      year: "2023",
      citationCount: 1203,
    },
    {
      title: `Power Consumption Patterns in Transformer Architectures`,
      authors: "Nguyen, T., Robinson, D., Clark, S.",
      abstract: `This research examines power consumption patterns across different transformer architectures, from BERT to GPT-4. We find that attention mechanisms account for 60-70% of computational overhead, suggesting optimization opportunities for more efficient model designs.`,
      venue: "IEEE Transactions on Neural Networks",
      year: "2024",
      citationCount: 189,
    },
    {
      title: `Data Center Energy Efficiency for AI Workloads`,
      authors: "White, J., Moore, E., Thompson, R.",
      abstract: `We analyze energy efficiency characteristics of data centers optimized for AI workloads. Our study covers hardware configurations, cooling systems, and operational strategies that can improve power usage effectiveness (PUE) for GPU-intensive computations.`,
      venue: "IEEE Computer",
      year: "2023",
      citationCount: 312,
    },
  ];

  const queryLower = query.toLowerCase();
  let results = topics.filter(
    (topic) =>
      topic.title.toLowerCase().includes(queryLower) ||
      topic.abstract.toLowerCase().includes(queryLower) ||
      topic.authors.toLowerCase().includes(queryLower)
  );

  if (results.length === 0) {
    results = topics.slice(0, 5);
  }

  return results.map((r) => ({
    ...r,
    scholarUrl: `https://scholar.google.com/scholar?q=${encodeURIComponent(r.title)}`,
    pdfUrl: Math.random() > 0.3 ? `https://arxiv.org/pdf/${Math.random().toString(36).substring(7)}` : undefined,
  }));
}
